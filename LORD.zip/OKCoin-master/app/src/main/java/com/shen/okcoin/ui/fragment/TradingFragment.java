package com.shen.okcoin.ui.fragment;

import com.shen.okcoin.R;
import com.shen.okcoin.base.SimpleFragment;

/**
 * Created by shenwangqiang on 2017/8/30.
 */
public class TradingFragment extends SimpleFragment {
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_trading;
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void setupView() {

    }
}
